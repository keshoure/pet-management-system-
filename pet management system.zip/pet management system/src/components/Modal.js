export class Modal {
  static open(title, htmlContent, onOpened = null) {
    const container = document.getElementById('modal-container');
    const content = document.getElementById('modal-content');
    if (!container || !content) return;

    content.innerHTML = `
      <div class="sheet-header" style="margin-bottom: var(--space-4);">
        <h3 class="sheet-title">${title}</h3>
        <button class="icon-btn" id="close-modal-btn">
          <i class="fa-solid fa-xmark"></i>
        </button>
      </div>
      <div class="modal-body-inner">
        ${htmlContent}
      </div>
    `;

    container.classList.remove('hidden');

    const closeBtn = document.getElementById('close-modal-btn');
    if (closeBtn) {
      closeBtn.onclick = () => Modal.close();
    }

    container.onclick = (e) => {
      if (e.target === container) {
        Modal.close();
      }
    };

    if (onOpened) {
      onOpened(content);
    }
  }

  static close() {
    const container = document.getElementById('modal-container');
    if (container) {
      container.classList.add('hidden');
    }
  }
}
