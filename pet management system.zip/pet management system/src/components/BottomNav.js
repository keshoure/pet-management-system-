import { store } from '../services/store.js';

export class BottomNav {
  constructor(container, onTabChange) {
    this.container = container;
    this.onTabChange = onTabChange;
    this.activeTab = 'dashboard';
    this.init();
  }

  init() {
    this.render();
    store.subscribe('activePetChanged', () => this.render());
    store.subscribe('remindersUpdated', () => this.render());
    store.subscribe('vaccinesUpdated', () => this.render());
  }

  setActiveTab(tabName) {
    this.activeTab = tabName;
    this.render();
  }

  render() {
    const activePet = store.getActivePet();
    const pendingReminders = store.getReminders(activePet?.id).filter(r => r.enabled && !r.completed).length;
    const dueVaccines = store.getVaccines(activePet?.id).filter(v => v.status === 'duesoon' || v.status === 'overdue').length;

    const navItems = [
      { id: 'dashboard', label: 'Home', icon: 'fa-house', badge: null },
      { id: 'pets', label: 'Pets', icon: 'fa-paw', badge: null },
      { id: 'vaccines', label: 'Vaccines', icon: 'fa-syringe', badge: dueVaccines > 0 ? dueVaccines : null },
      { id: 'appointments', label: 'Vet Visits', icon: 'fa-calendar-days', badge: null },
      { id: 'reminders', label: 'Routines', icon: 'fa-clipboard-check', badge: pendingReminders > 0 ? pendingReminders : null },
      { id: 'passport', label: 'Passport', icon: 'fa-id-card', badge: null }
    ];

    this.container.innerHTML = navItems.map(item => `
      <button class="nav-item ${this.activeTab === item.id ? 'active' : ''}" data-nav-id="${item.id}" id="nav-${item.id}-btn">
        <i class="fa-solid ${item.icon}"></i>
        <span>${item.label}</span>
        ${item.badge ? `<span class="nav-badge">${item.badge}</span>` : ''}
      </button>
    `).join('');

    this.bindEvents();
  }

  bindEvents() {
    this.container.querySelectorAll('[data-nav-id]').forEach(btn => {
      btn.onclick = () => {
        const tab = btn.getAttribute('data-nav-id');
        this.setActiveTab(tab);
        if (this.onTabChange) {
          this.onTabChange(tab);
        }
      };
    });
  }
}
