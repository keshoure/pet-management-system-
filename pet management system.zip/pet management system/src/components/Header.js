import { store } from '../services/store.js';
import { BottomSheet } from './BottomSheet.js';
import { Toast } from './Toast.js';

export class Header {
  constructor(container) {
    this.container = container;
    this.init();
  }

  init() {
    this.render();
    store.subscribe('activePetChanged', () => this.render());
    store.subscribe('petsUpdated', () => this.render());
    store.subscribe('themeChanged', () => this.render());
  }

  render() {
    const activePet = store.getActivePet();
    const currentTheme = store.getTheme();

    if (!activePet) {
      this.container.innerHTML = `
        <div class="header-left">
          <div class="app-brand">
            <div class="brand-icon"><i class="fa-solid fa-paw"></i></div>
            <span>PawPulse</span>
          </div>
        </div>
      `;
      return;
    }

    this.container.innerHTML = `
      <div class="header-left">
        <div class="app-brand" id="brand-home-btn" style="cursor: pointer;">
          <div class="brand-icon"><i class="fa-solid fa-paw"></i></div>
          <span style="font-size: 1.1rem; letter-spacing: -0.02em;">PawPulse</span>
        </div>
        <button class="pet-pill-selector" id="header-pet-selector" title="Switch active pet">
          <img src="${activePet.avatar}" alt="${activePet.name}" class="pet-pill-img" onerror="this.src='/images/pets/default-avatar.svg'" />
          <span>${activePet.name}</span>
          <i class="fa-solid fa-chevron-down" style="font-size: 0.65rem; opacity: 0.7;"></i>
        </button>
      </div>

      <div class="header-right">
        <!-- Theme Toggle -->
        <button class="icon-btn" id="theme-toggle-btn" title="Toggle Dark/Light Mode">
          <i class="fa-solid ${currentTheme === 'dark' ? 'fa-sun' : 'fa-moon'}"></i>
        </button>

        <!-- Notification Bell -->
        <button class="icon-btn" id="notifications-btn" title="Notifications">
          <i class="fa-regular fa-bell"></i>
          <span class="badge-dot"></span>
        </button>
      </div>
    `;

    this.bindEvents();
  }

  bindEvents() {
    const petSelectorBtn = document.getElementById('header-pet-selector');
    if (petSelectorBtn) {
      petSelectorBtn.onclick = () => this.openPetSwitcherSheet();
    }

    const themeToggleBtn = document.getElementById('theme-toggle-btn');
    if (themeToggleBtn) {
      themeToggleBtn.onclick = () => {
        const next = store.toggleTheme();
        Toast.show(`Switched to ${next === 'dark' ? 'Dark' : 'Light'} Mode`, 'info', 2000);
      };
    }

    const notifBtn = document.getElementById('notifications-btn');
    if (notifBtn) {
      notifBtn.onclick = () => this.openNotificationsSheet();
    }

    const brandBtn = document.getElementById('brand-home-btn');
    if (brandBtn) {
      brandBtn.onclick = () => {
        if (window.appRouter) window.appRouter.navigate('dashboard');
      };
    }
  }

  openPetSwitcherSheet() {
    const pets = store.getPets();
    const activePet = store.getActivePet();

    const html = `
      <p class="text-secondary" style="font-size: 0.85rem; margin-bottom: var(--space-4);">
        Select which pet profile to manage:
      </p>
      <div class="pet-switcher-list" style="display: flex; flex-direction: column; gap: var(--space-3); margin-bottom: var(--space-5);">
        ${pets.map(p => `
          <div class="pet-card ${p.id === activePet?.id ? 'active-selected' : ''}" data-pet-id="${p.id}" style="padding: 0.75rem 1rem; cursor: pointer;">
            <div class="pet-card-top" style="gap: 0.75rem;">
              <img src="${p.avatar}" alt="${p.name}" class="pet-card-avatar" style="width: 46px; height: 46px;" onerror="this.src='/images/pets/default-avatar.svg'" />
              <div class="pet-card-main">
                <div class="pet-card-name-row">
                  <span class="pet-card-name" style="font-size: 1rem;">${p.name}</span>
                  ${p.id === activePet?.id ? '<span class="badge badge-primary"><i class="fa-solid fa-check"></i> Active</span>' : ''}
                </div>
                <span class="pet-card-breed" style="font-size: 0.78rem;">${p.breed} • ${p.age}</span>
              </div>
            </div>
          </div>
        `).join('')}
      </div>
      <button class="btn btn-secondary btn-block" id="sheet-add-pet-btn">
        <i class="fa-solid fa-plus"></i> Add New Pet Profile
      </button>
    `;

    BottomSheet.open('Switch Active Pet', html, (content) => {
      content.querySelectorAll('[data-pet-id]').forEach(item => {
        item.onclick = () => {
          const pid = item.getAttribute('data-pet-id');
          store.setActivePet(pid);
          BottomSheet.close();
          Toast.show(`Switched active pet to ${store.getPet(pid)?.name}`, 'success');
        };
      });

      const addBtn = content.querySelector('#sheet-add-pet-btn');
      if (addBtn) {
        addBtn.onclick = () => {
          BottomSheet.close();
          if (window.appRouter) {
            window.appRouter.navigate('pets');
            setTimeout(() => {
              if (window.petsView) window.petsView.openAddPetModal();
            }, 300);
          }
        };
      }
    });
  }

  openNotificationsSheet() {
    const activePet = store.getActivePet();
    const vaccines = store.getVaccines(activePet?.id).filter(v => v.status === 'duesoon' || v.status === 'overdue');
    const appointments = store.getAppointments(activePet?.id).filter(a => a.status === 'upcoming');
    const reminders = store.getReminders(activePet?.id).filter(r => r.enabled && !r.completed);

    const html = `
      <div style="display: flex; flex-direction: column; gap: var(--space-4);">
        <div>
          <h4 style="font-size: 0.95rem; font-weight: 700; margin-bottom: 0.5rem; display: flex; align-items: center; gap: 0.4rem;">
            <i class="fa-solid fa-bell text-primary-brand"></i> Important Alerts for ${activePet?.name || 'Pet'}
          </h4>
        </div>

        ${vaccines.length > 0 ? `
          <div style="background: rgba(245, 158, 11, 0.1); border-left: 4px solid var(--accent-amber-500); padding: 0.75rem 1rem; border-radius: var(--radius-md);">
            <div style="font-weight: 700; font-size: 0.88rem; color: var(--accent-amber-600); margin-bottom: 0.2rem;">
              <i class="fa-solid fa-syringe"></i> Vaccination Action Needed
            </div>
            <div style="font-size: 0.8rem; color: var(--text-secondary);">
              ${vaccines.map(v => `${v.name} (Due: ${v.nextDueDate})`).join(', ')}
            </div>
          </div>
        ` : ''}

        ${appointments.length > 0 ? `
          <div style="background: rgba(99, 102, 241, 0.1); border-left: 4px solid var(--accent-indigo-500); padding: 0.75rem 1rem; border-radius: var(--radius-md);">
            <div style="font-weight: 700; font-size: 0.88rem; color: var(--accent-indigo-600); margin-bottom: 0.2rem;">
              <i class="fa-regular fa-calendar-check"></i> Upcoming Appointment
            </div>
            <div style="font-size: 0.8rem; color: var(--text-secondary);">
              ${appointments[0].title} on ${appointments[0].date} at ${appointments[0].time} (${appointments[0].clinic})
            </div>
          </div>
        ` : ''}

        <div style="display: flex; flex-direction: column; gap: 0.5rem;">
          <span style="font-size: 0.82rem; font-weight: 700; color: var(--text-muted);">Today's Pending Tasks (${reminders.length})</span>
          ${reminders.length === 0 ? '<p class="text-secondary" style="font-size: 0.82rem;">All daily tasks completed! 🎉</p>' : reminders.map(r => `
            <div style="display: flex; align-items: center; justify-content: space-between; padding: 0.5rem 0.75rem; background: var(--bg-subtle); border-radius: var(--radius-sm); font-size: 0.82rem;">
              <span><i class="fa-solid ${r.icon} text-primary-brand"></i> ${r.title}</span>
              <span class="text-muted">${r.time}</span>
            </div>
          `).join('')}
        </div>
      </div>
    `;

    BottomSheet.open('Notification Center', html);
  }
}
