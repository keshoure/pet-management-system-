export class BottomSheet {
  static open(title, htmlContent, onOpened = null) {
    const container = document.getElementById('bottom-sheet-container');
    const content = document.getElementById('bottom-sheet-content');
    if (!container || !content) return;

    content.innerHTML = `
      <div class="sheet-header">
        <h3 class="sheet-title">${title}</h3>
        <button class="icon-btn" id="close-sheet-btn">
          <i class="fa-solid fa-xmark"></i>
        </button>
      </div>
      <div class="sheet-body-inner">
        ${htmlContent}
      </div>
    `;

    container.classList.remove('hidden');

    const closeBtn = document.getElementById('close-sheet-btn');
    if (closeBtn) {
      closeBtn.onclick = () => BottomSheet.close();
    }

    container.onclick = (e) => {
      if (e.target === container) {
        BottomSheet.close();
      }
    };

    if (onOpened) {
      onOpened(content);
    }
  }

  static close() {
    const container = document.getElementById('bottom-sheet-container');
    if (container) {
      container.classList.add('hidden');
    }
  }
}
