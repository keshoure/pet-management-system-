import { store } from '../services/store.js';
import { Toast } from '../components/Toast.js';

export class WebsiteController {
  constructor() {
    this.pricingPeriod = 'annual'; // 'monthly' | 'annual'
    this.init();
  }

  init() {
    this.setupDualViewSwitcher();
    this.setupHealthCalculator();
    this.setupPricingSwitcher();
    this.setupFAQAccordion();
    this.setupVetFilter();
    this.setupPlayStoreModal();
    this.setupSmoothScroll();
  }

  // Dual View Mode: Website ↔ App
  setupDualViewSwitcher() {
    const websiteRoot = document.getElementById('website-root');
    const appRoot = document.getElementById('app-root');
    const dualBtns = document.querySelectorAll('.dual-btn, .nav-launch-app-btn, .hero-launch-app-btn');

    const setMode = (mode) => {
      if (mode === 'app') {
        if (websiteRoot) websiteRoot.classList.add('hidden');
        if (appRoot) appRoot.classList.remove('hidden');
        document.querySelectorAll('.dual-btn').forEach(b => {
          b.classList.toggle('active', b.getAttribute('data-view-target') === 'app');
        });
      } else {
        if (websiteRoot) websiteRoot.classList.remove('hidden');
        if (appRoot) appRoot.classList.add('hidden');
        document.querySelectorAll('.dual-btn').forEach(b => {
          b.classList.toggle('active', b.getAttribute('data-view-target') === 'website');
        });
      }
    };

    dualBtns.forEach(btn => {
      btn.onclick = (e) => {
        e.preventDefault();
        const target = btn.getAttribute('data-view-target') || 'app';
        setMode(target);
        if (target === 'app') {
          Toast.show('Switched to PawPulse App View', 'info', 2000);
        }
      };
    });
  }

  // Pet Health & Calorie Calculator
  setupHealthCalculator() {
    const speciesSel = document.getElementById('calc-species');
    const weightInput = document.getElementById('calc-weight');
    const activitySel = document.getElementById('calc-activity');
    const ageInput = document.getElementById('calc-age');

    const caloriesOut = document.getElementById('calc-out-calories');
    const waterOut = document.getElementById('calc-out-water');
    const humanAgeOut = document.getElementById('calc-out-human-age');

    const updateCalc = () => {
      if (!speciesSel || !weightInput || !activitySel) return;
      const species = speciesSel.value; // 'dog' | 'cat'
      const weight = parseFloat(weightInput.value) || 10;
      const activity = parseFloat(activitySel.value) || 1.6;
      const petAge = parseFloat(ageInput ? ageInput.value : 2) || 2;

      // Resting Energy Requirement (RER) in kcal
      const rer = 70 * Math.pow(weight, 0.75);
      const der = Math.round(rer * activity);

      // Water in ml/day (~50-60ml per kg)
      const waterMl = Math.round(weight * 55);

      // Human age equivalent
      let humanAge = 0;
      if (species === 'cat') {
        humanAge = petAge <= 1 ? 15 : petAge === 2 ? 24 : 24 + (petAge - 2) * 4;
      } else {
        // Dog (medium avg)
        humanAge = petAge <= 1 ? 15 : petAge === 2 ? 24 : 24 + (petAge - 2) * 5;
      }

      if (caloriesOut) caloriesOut.innerText = `${der} kcal/day`;
      if (waterOut) waterOut.innerText = `${waterMl} ml/day`;
      if (humanAgeOut) humanAgeOut.innerText = `≈ ${Math.round(humanAge)} human yrs`;
    };

    [speciesSel, weightInput, activitySel, ageInput].forEach(el => {
      if (el) {
        el.addEventListener('input', updateCalc);
        el.addEventListener('change', updateCalc);
      }
    });

    updateCalc();
  }

  // Pricing Toggle (Monthly vs Annual)
  setupPricingSwitcher() {
    const monthlyBtn = document.getElementById('pricing-opt-monthly');
    const annualBtn = document.getElementById('pricing-opt-annual');

    const plusPrice = document.getElementById('price-plus-amt');
    const unlimitedPrice = document.getElementById('price-unlimited-amt');

    if (monthlyBtn && annualBtn) {
      monthlyBtn.onclick = () => {
        this.pricingPeriod = 'monthly';
        monthlyBtn.classList.add('active');
        annualBtn.classList.remove('active');
        if (plusPrice) plusPrice.innerText = '4.99';
        if (unlimitedPrice) unlimitedPrice.innerText = '9.99';
      };

      annualBtn.onclick = () => {
        this.pricingPeriod = 'annual';
        annualBtn.classList.add('active');
        monthlyBtn.classList.remove('active');
        if (plusPrice) plusPrice.innerText = '3.99';
        if (unlimitedPrice) unlimitedPrice.innerText = '7.99';
      };
    }
  }

  // FAQ Accordions
  setupFAQAccordion() {
    document.querySelectorAll('.faq-item').forEach(item => {
      const q = item.querySelector('.faq-question');
      if (q) {
        q.onclick = () => {
          const isOpen = item.classList.contains('open');
          document.querySelectorAll('.faq-item').forEach(i => i.classList.remove('open'));
          if (!isOpen) {
            item.classList.add('open');
          }
        };
      }
    });
  }

  // Vet Clinic Directory Filter
  setupVetFilter() {
    const filterBtns = document.querySelectorAll('[data-vet-filter]');
    const vetCards = document.querySelectorAll('.vet-card');

    filterBtns.forEach(btn => {
      btn.onclick = () => {
        filterBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const filter = btn.getAttribute('data-vet-filter');

        vetCards.forEach(card => {
          const type = card.getAttribute('data-vet-type');
          if (filter === 'all' || type.includes(filter)) {
            card.style.display = 'flex';
          } else {
            card.style.display = 'none';
          }
        });
      };
    });
  }

  // Play Store & App Store Download Modal
  setupPlayStoreModal() {
    let deferredPrompt = null;
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      deferredPrompt = e;
    });

    document.querySelectorAll('.open-store-modal-btn').forEach(btn => {
      btn.onclick = (e) => {
        e.preventDefault();
        const storeType = btn.getAttribute('data-store') || 'google-play';
        const isGooglePlay = storeType === 'google-play';

        const html = `
          <div style="text-align: center; display: flex; flex-direction: column; align-items: center; gap: var(--space-4);">
            <div style="width: 56px; height: 56px; border-radius: var(--radius-md); background: ${isGooglePlay ? 'rgba(16, 185, 129, 0.12)' : 'rgba(99, 102, 241, 0.12)'}; color: ${isGooglePlay ? 'var(--primary-600)' : 'var(--accent-indigo-500)'}; display: flex; align-items: center; justify-content: center; font-size: 1.75rem;">
              <i class="fa-brands ${isGooglePlay ? 'fa-google-play' : 'fa-apple'}"></i>
            </div>
            <div>
              <h3 style="font-size: 1.25rem; font-weight: 800;">${isGooglePlay ? 'Google Play Store' : 'Apple App Store'}</h3>
              <p class="text-secondary" style="font-size: 0.85rem; margin-top: 0.2rem;">
                PawPulse Pet Care Management • Rated 4.9 ★ (50k+ Reviews)
              </p>
            </div>

            <!-- Instant PWA Install / WebAPK -->
            <button class="btn btn-primary btn-block" id="modal-pwa-install-btn">
              <i class="fa-solid fa-download"></i> Install App on Device
            </button>

            <!-- Standalone App Link -->
            <a href="/app.html" class="btn btn-secondary btn-block">
              <i class="fa-solid fa-mobile-screen"></i> Open Full-Screen Web App
            </a>
          </div>
        `;

        const modalContainer = document.getElementById('modal-container');
        const modalContent = document.getElementById('modal-content');
        if (modalContainer && modalContent) {
          modalContent.innerHTML = `
            <div class="sheet-header" style="margin-bottom: var(--space-4);">
              <h3 class="sheet-title">Get PawPulse Mobile</h3>
              <button class="icon-btn" id="close-store-modal-btn">
                <i class="fa-solid fa-xmark"></i>
              </button>
            </div>
            ${html}
          `;
          modalContainer.classList.remove('hidden');

          const closeBtn = document.getElementById('close-store-modal-btn');
          if (closeBtn) closeBtn.onclick = () => modalContainer.classList.add('hidden');

          const installBtn = document.getElementById('modal-pwa-install-btn');
          if (installBtn) {
            installBtn.onclick = async () => {
              if (deferredPrompt) {
                deferredPrompt.prompt();
                const { outcome } = await deferredPrompt.userChoice;
                if (outcome === 'accepted') {
                  Toast.show('PawPulse app installed successfully!', 'success');
                }
                deferredPrompt = null;
              } else {
                window.location.href = '/app.html';
              }
            };
          }
        }
      };
    });
  }

  // Smooth Scroll for Nav Links
  setupSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.onclick = (e) => {
        const href = anchor.getAttribute('href');
        if (href === '#' || href === '#app') return;
        const target = document.querySelector(href);
        if (target) {
          e.preventDefault();
          target.scrollIntoView({ behavior: 'smooth' });
        }
      };
    });
  }
}
