import { INITIAL_DATA } from '../data/initialData.js';

const STORAGE_KEY = 'pawpulse_pet_management_v1';

class Store {
  constructor() {
    this.subscribers = new Map();
    this.state = this.loadState();
  }

  loadState() {
    try {
      const serialized = localStorage.getItem(STORAGE_KEY);
      if (serialized) {
        return JSON.parse(serialized);
      }
    } catch (e) {
      console.warn('Failed to load state from localStorage', e);
    }
    return JSON.parse(JSON.stringify(INITIAL_DATA));
  }

  saveState() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.state));
    } catch (e) {
      console.error('Failed to save state to localStorage', e);
    }
  }

  // Pub/Sub Event System
  subscribe(event, callback) {
    if (!this.subscribers.has(event)) {
      this.subscribers.set(event, []);
    }
    this.subscribers.get(event).push(callback);
    return () => {
      const callbacks = this.subscribers.get(event);
      if (callbacks) {
        this.subscribers.set(event, callbacks.filter(cb => cb !== callback));
      }
    };
  }

  emit(event, data) {
    if (this.subscribers.has(event)) {
      this.subscribers.get(event).forEach(cb => {
        try {
          cb(data);
        } catch (e) {
          console.error(`Error in subscriber for ${event}:`, e);
        }
      });
    }
  }

  // --- Pets ---
  getPets() {
    return this.state.pets || [];
  }

  getPet(id) {
    return (this.state.pets || []).find(p => p.id === id) || null;
  }

  getActivePet() {
    const active = this.getPet(this.state.activePetId);
    return active || this.getPets()[0] || null;
  }

  setActivePet(petId) {
    this.state.activePetId = petId;
    this.saveState();
    this.emit('activePetChanged', this.getActivePet());
    this.emit('stateChanged', this.state);
  }

  addPet(petData) {
    const newId = `pet-${Date.now()}`;
    const newPet = {
      id: newId,
      name: petData.name || 'New Pet',
      species: petData.species || 'Dog',
      breed: petData.breed || 'Mixed Breed',
      gender: petData.gender || 'Unknown',
      dob: petData.dob || new Date().toISOString().split('T')[0],
      age: petData.age || 'Puppy / Kitten',
      weight: parseFloat(petData.weight) || 5.0,
      weightUnit: petData.weightUnit || 'kg',
      color: petData.color || 'Tan',
      microchip: petData.microchip || `${Math.floor(100+Math.random()*900)}-${Math.floor(100+Math.random()*900)}-001`,
      avatar: petData.avatar || '/images/pets/default-avatar.svg',
      allergies: petData.allergies ? petData.allergies.split(',').map(s => s.trim()).filter(Boolean) : [],
      diet: petData.diet || 'Standard balanced pet food',
      vetClinic: petData.vetClinic || 'City Vet Hospital',
      vetDoctor: petData.vetDoctor || 'Dr. Pet Care',
      vetPhone: petData.vetPhone || '+1 (555) 000-0000',
      vetAddress: petData.vetAddress || 'Main Street Vet Clinic',
      passportId: `USA-${(petData.species || 'PET').toUpperCase()}-2024-${Math.floor(1000 + Math.random() * 9000)}`,
      weightHistory: [
        { date: new Date().toISOString().split('T')[0], weight: parseFloat(petData.weight) || 5.0 }
      ]
    };
    this.state.pets.push(newPet);
    this.state.activePetId = newId;
    this.saveState();
    this.emit('petsUpdated', this.getPets());
    this.emit('activePetChanged', newPet);
    this.emit('stateChanged', this.state);
    return newPet;
  }

  updatePet(id, updatedFields) {
    const petIndex = this.state.pets.findIndex(p => p.id === id);
    if (petIndex !== -1) {
      this.state.pets[petIndex] = { ...this.state.pets[petIndex], ...updatedFields };
      this.saveState();
      this.emit('petsUpdated', this.getPets());
      if (this.state.activePetId === id) {
        this.emit('activePetChanged', this.state.pets[petIndex]);
      }
      this.emit('stateChanged', this.state);
    }
  }

  deletePet(id) {
    this.state.pets = this.state.pets.filter(p => p.id !== id);
    if (this.state.activePetId === id) {
      this.state.activePetId = this.state.pets[0]?.id || null;
    }
    this.saveState();
    this.emit('petsUpdated', this.getPets());
    this.emit('activePetChanged', this.getActivePet());
    this.emit('stateChanged', this.state);
  }

  logWeight(petId, weightVal, dateStr = new Date().toISOString().split('T')[0]) {
    const pet = this.getPet(petId);
    if (pet) {
      const weightNum = parseFloat(weightVal);
      pet.weight = weightNum;
      if (!pet.weightHistory) pet.weightHistory = [];
      pet.weightHistory.push({ date: dateStr, weight: weightNum });
      // Keep sorted by date
      pet.weightHistory.sort((a, b) => new Date(a.date) - new Date(b.date));
      this.saveState();
      this.emit('petsUpdated', this.getPets());
      this.emit('activePetChanged', pet);
      this.emit('stateChanged', this.state);
    }
  }

  // --- Vaccines ---
  getVaccines(petId = null) {
    if (petId) {
      return (this.state.vaccines || []).filter(v => v.petId === petId);
    }
    return this.state.vaccines || [];
  }

  addVaccine(vaccineData) {
    const newVac = {
      id: `vac-${Date.now()}`,
      petId: vaccineData.petId || this.state.activePetId,
      name: vaccineData.name,
      targetDisease: vaccineData.targetDisease || vaccineData.name,
      administeredDate: vaccineData.administeredDate || new Date().toISOString().split('T')[0],
      nextDueDate: vaccineData.nextDueDate,
      batchNo: vaccineData.batchNo || `BAT-${Math.floor(10000 + Math.random() * 90000)}`,
      provider: vaccineData.provider || 'Animal Clinic',
      status: vaccineData.status || 'uptodate',
      verified: true
    };
    this.state.vaccines.unshift(newVac);
    this.saveState();
    this.emit('vaccinesUpdated', this.getVaccines());
    this.emit('stateChanged', this.state);
    return newVac;
  }

  deleteVaccine(id) {
    this.state.vaccines = this.state.vaccines.filter(v => v.id !== id);
    this.saveState();
    this.emit('vaccinesUpdated', this.getVaccines());
    this.emit('stateChanged', this.state);
  }

  // --- Medications ---
  getMedications(petId = null) {
    if (petId) {
      return (this.state.medications || []).filter(m => m.petId === petId);
    }
    return this.state.medications || [];
  }

  toggleMedicationTaken(medId) {
    const med = (this.state.medications || []).find(m => m.id === medId);
    if (med) {
      med.takenToday = !med.takenToday;
      if (med.takenToday) {
        med.lastTaken = new Date().toISOString().split('T')[0];
      }
      this.saveState();
      this.emit('medicationsUpdated', this.getMedications());
      this.emit('stateChanged', this.state);
    }
  }

  addMedication(medData) {
    const newMed = {
      id: `med-${Date.now()}`,
      petId: medData.petId || this.state.activePetId,
      name: medData.name,
      dosage: medData.dosage,
      frequency: medData.frequency || 'Daily',
      purpose: medData.purpose || 'Health Maintenance',
      time: medData.time || '08:00 AM',
      takenToday: false,
      lastTaken: null
    };
    this.state.medications.push(newMed);
    this.saveState();
    this.emit('medicationsUpdated', this.getMedications());
    this.emit('stateChanged', this.state);
    return newMed;
  }

  deleteMedication(id) {
    this.state.medications = this.state.medications.filter(m => m.id !== id);
    this.saveState();
    this.emit('medicationsUpdated', this.getMedications());
    this.emit('stateChanged', this.state);
  }

  // --- Appointments ---
  getAppointments(petId = null) {
    if (petId) {
      return (this.state.appointments || []).filter(a => a.petId === petId);
    }
    return this.state.appointments || [];
  }

  addAppointment(data) {
    const newAppt = {
      id: `appt-${Date.now()}`,
      petId: data.petId || this.state.activePetId,
      title: data.title,
      type: data.type || 'Checkup',
      date: data.date,
      time: data.time || '10:00 AM',
      clinic: data.clinic || 'Metropolis Animal Hospital',
      doctor: data.doctor || 'Dr. Jenkins',
      phone: data.phone || '+1 (555) 382-9901',
      address: data.address || '742 Evergreen Terrace',
      status: 'upcoming',
      notes: data.notes || ''
    };
    this.state.appointments.unshift(newAppt);
    this.saveState();
    this.emit('appointmentsUpdated', this.getAppointments());
    this.emit('stateChanged', this.state);
    return newAppt;
  }

  deleteAppointment(id) {
    this.state.appointments = this.state.appointments.filter(a => a.id !== id);
    this.saveState();
    this.emit('appointmentsUpdated', this.getAppointments());
    this.emit('stateChanged', this.state);
  }

  // --- Reminders ---
  getReminders(petId = null) {
    if (petId) {
      return (this.state.reminders || []).filter(r => r.petId === petId);
    }
    return this.state.reminders || [];
  }

  toggleReminderCompleted(remId) {
    const rem = (this.state.reminders || []).find(r => r.id === remId);
    if (rem) {
      rem.completed = !rem.completed;
      this.saveState();
      this.emit('remindersUpdated', this.getReminders());
      this.emit('stateChanged', this.state);
    }
  }

  toggleReminderEnabled(remId) {
    const rem = (this.state.reminders || []).find(r => r.id === remId);
    if (rem) {
      rem.enabled = !rem.enabled;
      this.saveState();
      this.emit('remindersUpdated', this.getReminders());
      this.emit('stateChanged', this.state);
    }
  }

  addReminder(data) {
    const newRem = {
      id: `rem-${Date.now()}`,
      petId: data.petId || this.state.activePetId,
      title: data.title,
      time: data.time || '08:00 AM',
      category: data.category || 'general',
      icon: data.icon || 'fa-bell',
      color: data.color || 'teal',
      enabled: true,
      completed: false
    };
    this.state.reminders.push(newRem);
    this.saveState();
    this.emit('remindersUpdated', this.getReminders());
    this.emit('stateChanged', this.state);
    return newRem;
  }

  deleteReminder(id) {
    this.state.reminders = this.state.reminders.filter(r => r.id !== id);
    this.saveState();
    this.emit('remindersUpdated', this.getReminders());
    this.emit('stateChanged', this.state);
  }

  // --- Medical Records ---
  getMedicalRecords(petId = null) {
    if (petId) {
      return (this.state.medicalRecords || []).filter(m => m.petId === petId);
    }
    return this.state.medicalRecords || [];
  }

  addMedicalRecord(data) {
    const newRec = {
      id: `rec-${Date.now()}`,
      petId: data.petId || this.state.activePetId,
      title: data.title,
      date: data.date || new Date().toISOString().split('T')[0],
      type: data.type || 'General',
      vet: data.vet || 'Dr. Sarah Jenkins',
      notes: data.notes || '',
      attachments: []
    };
    this.state.medicalRecords.unshift(newRec);
    this.saveState();
    this.emit('medicalRecordsUpdated', this.getMedicalRecords());
    this.emit('stateChanged', this.state);
    return newRec;
  }

  // --- Theme & View Mode ---
  getTheme() {
    return this.state.theme || 'light';
  }

  setTheme(theme) {
    this.state.theme = theme;
    document.documentElement.setAttribute('data-theme', theme);
    this.saveState();
    this.emit('themeChanged', theme);
  }

  toggleTheme() {
    const nextTheme = this.getTheme() === 'light' ? 'dark' : 'light';
    this.setTheme(nextTheme);
    return nextTheme;
  }

  getViewMode() {
    return this.state.viewMode || 'mobile';
  }

  toggleViewMode() {
    this.state.viewMode = this.state.viewMode === 'mobile' ? 'expanded' : 'mobile';
    const appRoot = document.getElementById('app-root');
    if (appRoot) {
      if (this.state.viewMode === 'expanded') {
        appRoot.classList.add('expanded-view');
      } else {
        appRoot.classList.remove('expanded-view');
      }
    }
    this.saveState();
    this.emit('viewModeChanged', this.state.viewMode);
    return this.state.viewMode;
  }

  resetToDefaults() {
    this.state = JSON.parse(JSON.stringify(INITIAL_DATA));
    this.saveState();
    this.emit('stateChanged', this.state);
    this.emit('activePetChanged', this.getActivePet());
  }
}

export const store = new Store();
